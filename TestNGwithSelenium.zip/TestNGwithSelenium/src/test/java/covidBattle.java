
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import utils.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;


public class covidBattle {
    public static WebDriver driver =null;
    public static ExtentTest test;
    public  static ExtentReports reports;

        @BeforeClass
        public static void beginTest(){
            String log4jConfPath="log4j.properties";
            PropertyConfigurator.configure(log4jConfPath);
            java.util.logging.Logger.getLogger("org.apache.http.wire").setLevel(java.util.logging.Level.FINEST);
            java.util.logging.Logger.getLogger("org.apache.http.headers").setLevel(java.util.logging.Level.FINEST);
            System.setProperty("org.apache.commons.logging.Log", "org.apache.commons.logging.impl.SimpleLog");
            System.setProperty("org.apache.commons.logging.simplelog.showdatetime", "true");
            System.setProperty("org.apache.commons.logging.simplelog.log.httpclient.wire", "ERROR");
            System.setProperty("org.apache.commons.logging.simplelog.log.org.apache.http", "ERROR");
            System.setProperty("org.apache.commons.logging.simplelog.log.org.apache.http.headers", "ERROR");
            Log.startTestCase("Response to Covid");
            disableSeleniumLogs();

            reports = new ExtentReports ("\\TestNGwithSelenium\\test-output\\STMExtentReport.html", true);
            reports.loadConfig(new File("\\TestNGwithSelenium\\extent-config.xml"));

           test = reports.startTest("ExtentReport");
            Log.info("-------------Intiating the browser---------------");
            System.setProperty("webdriver.chrome.driver","\\TestNGwithSelenium\\chromedriver.exe");
            driver = new ChromeDriver();
        }

    public static void disableSeleniumLogs() {
        System.setProperty(ChromeDriverService.CHROME_DRIVER_SILENT_OUTPUT_PROPERTY, "true");
        Logger.getLogger("org.openqa.selenium").setLevel(Level.OFF);
    }
        @BeforeTest
        public void login(){
            Log.info("-------------Beginning Test----------------");

        }

        @Test
        public static void createUser() throws InterruptedException, IOException {
    Log.info("-------------Creating User-----------------");

    Properties obj = new Properties();
    FileInputStream objfile = new FileInputStream(System.getProperty("user.dir") + "\\objectRepository.properties");
    obj.load(objfile);
    driver.get("http://responsivefight.herokuapp.com/");
    driver.manage().window().maximize();
    WebDriverWait wait = new WebDriverWait(driver, 20);
    System.setProperty("webdriver.chrome.silentOutput", "true");
    test.log(LogStatus.PASS, "Navigated to the specified URL");

    //Creating a new user
    driver.findElement(By.id(obj.getProperty("warriorUsername"))).sendKeys(obj.getProperty("username"));
    wait.until(ExpectedConditions.elementToBeClickable(By.id(obj.getProperty("createWarriorButton")))).click();
    Assert.assertEquals(driver.findElement(By.id(obj.getProperty("startButton"))).getText(), "Start your journey " + obj.getProperty("username"));
    driver.findElement(By.id(obj.getProperty("startButton"))).click();
    test.log(LogStatus.PASS, "Created User");

    //bus Challenge
    Log.info("-------------Initiating the Bus Challenge-----------------");
    wait.until(ExpectedConditions.elementToBeClickable(By.id(obj.getProperty("busButton")))).click();
    wait.until(ExpectedConditions.elementToBeClickable(By.id(obj.getProperty("busTimer")))).click();
    driver.findElement(By.id(obj.getProperty("busAnswerOne"))).click();
    wait.until(ExpectedConditions.elementToBeClickable(By.id(obj.getProperty("modalButton")))).click();
    test.log(LogStatus.PASS, "Completed Bus Challenge");

    //rest Challenge
    Log.info("-------------Initiating the Restaurant Challenge-----------------");
    wait.until(ExpectedConditions.elementToBeClickable(By.id(obj.getProperty("restTimer")))).click();
    wait.until(ExpectedConditions.elementToBeClickable(By.id(obj.getProperty("restAnswerOne")))).click();
    wait.until(ExpectedConditions.elementToBeClickable(By.id(obj.getProperty("modalButton")))).click();
    test.log(LogStatus.PASS, "Completed Restaurant Challenge");

    //Office Challenge
    Log.info("-------------Initiating the Office Challenge-----------------");
    wait.until(ExpectedConditions.elementToBeClickable(By.id(obj.getProperty("startButton")))).click();
    driver.findElement(By.id(obj.getProperty("officeAnswerOne"))).click();
    test.log(LogStatus.PASS, "Completed Office Challenge");

    //Go to Leaderboard
    Log.info("-------------Navigating to the Leader Board-----------------");
    wait.until(ExpectedConditions.elementToBeClickable(By.id(obj.getProperty("leaderLink")))).click();
    Thread.sleep(2000);
    Assert.assertEquals(driver.findElement(By.xpath(obj.getProperty("leaderBoardTitle"))).getText().trim(), "COVID-19 THE GAME - LEADERBOARD");
    System.out.println("Highest Score is = " + driver.findElement(By.xpath(obj.getProperty("readScore"))).getText());
    test.log(LogStatus.PASS, "Navigated to Leader Board");

        }

        @AfterTest
        private static void close(){
                reports.endTest(test);
                reports.flush();
            Log.endTestCase("Execution Complete");
            driver.quit();
        }
    }



