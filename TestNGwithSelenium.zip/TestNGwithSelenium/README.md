# How to run the project

*Entry Criteria:*

- Install Java and supporting tools
- Install IntelliJ Community Edition and plugins
    - check IntelliJ works by running the sample test

## Execution

*  Import the maven project in your IDE.
   *  Sync POM if auto import is disabled
* Navigate to testNG.xml 
* Right click and select "Run <FileName>.testNG"

*Test Artifacts:*

- Logs will be generated in the console and also under /target/test.log -with log4j
- Each test will marked individually as pass/fail in the run tab with messages -TestNG
- STMExtentReport.html reports will be using - extent reports.

