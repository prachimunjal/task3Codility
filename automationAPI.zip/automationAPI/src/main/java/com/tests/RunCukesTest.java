package com.tests;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/main/resources/Features/",
        glue = {"com.tests"},
        tags = {"@Regression"}
       // plugin = {"json:target/cucumber-report.json","usage"}
)
public class RunCukesTest {

}