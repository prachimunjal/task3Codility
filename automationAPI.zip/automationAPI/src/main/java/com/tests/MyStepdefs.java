package com.tests;

import com.utils.Log;
import cucumber.api.java.After;
import org.apache.log4j.PropertyConfigurator;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.cucumber.datatable.DataTable;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;
import cucumber.api.java.Before;
import java.util.Map;


import static io.restassured.RestAssured.baseURI;

public class MyStepdefs {
    public String addURI;
    private static Response response;
    private static RequestSpecification request;

    @Before("@Smoke")
    public void setLog()
    {
        String log4jConfPath="log4j.properties";
        PropertyConfigurator.configure(log4jConfPath);
        java.util.logging.Logger.getLogger("org.apache.http.wire").setLevel(java.util.logging.Level.FINEST);
        java.util.logging.Logger.getLogger("org.apache.http.headers").setLevel(java.util.logging.Level.FINEST);
        System.setProperty("org.apache.commons.logging.Log", "org.apache.commons.logging.impl.SimpleLog");
        System.setProperty("org.apache.commons.logging.simplelog.showdatetime", "true");
        System.setProperty("org.apache.commons.logging.simplelog.log.httpclient.wire", "ERROR");
        System.setProperty("org.apache.commons.logging.simplelog.log.org.apache.http", "ERROR");
        System.setProperty("org.apache.commons.logging.simplelog.log.org.apache.http.headers", "ERROR");
        Log.startTestCase("Starting the execution of Test");
    }

    @Given("^Get the API Url$")
    public void getTheAPIUrl() {

        Log.info("--------------Setting up the base url-----------------------");
        addURI = "https://supervillain.herokuapp.com/v1/user";
        System.out.println("Add URL :"+addURI);
        RestAssured.baseURI = addURI;
        request = RestAssured.given();
    }

    @Then("Construct the user request body with the {string} and {string}")
    public void constructTheUserRequestBodyWithTheAnd(String userName, String score) {
        Log.info("--------------Adding "+ userName +" into the list-----------------------");
        request.header("Content-Type", "application/json");
        response = request.body("{ \"username\":\"" + userName + "\", \"score\":\"" + score + "\"}")
                .post("");

        response.prettyPrint();
    }

    @And("Verify if the status code is {string}")
    public void verifyIfTheStatusCodeIs(String statusCode) {
        Log.info("--------------Validating the status code------------------------");
        Assert.assertEquals(Integer.parseInt(statusCode), response.getStatusCode());
    }

    @And("Verify if the response contains the following info")
    public void verifyIfTheResponseContainsTheFollowingInfo(DataTable db) {
        Log.info("--------------Verify if the response contains the expected info-------------------");
        response = request.get("https://supervillain.herokuapp.com/v1/user");
        response.prettyPrint();
        Map<String, String> resultMap = db.asMap(String.class, String.class);
        for (Map.Entry<String, String> entry : resultMap.entrySet()){
        String a = entry.getValue();
        Assert.assertTrue(response.jsonPath().getString(entry.getKey()).contains(a));
        }
        Log.info("-------Information has been  successfully added/updated-----------");
    }

    @Then("Update the user request body with the {string} and {string}")
    public void updateTheUserRequestBodyWithTheAnd(String userName, String score) {
        Log.info("----------------Updating User--------------------------");
        request.header("Content-Type", "application/json");
        response = request.body("{ \"username\":\"" + userName + "\", \"score\":\"" + score + "\"}")
                .put("https://supervillain.herokuapp.com/v1/user");

    }

    @Then("Delete the user list")
    public void deleteTheUserList() {
        Log.info("----------------Attempting to delete list of users-------------------");
        response = request.delete(baseURI);
    }

    @Then("extract the list of users")
    public void extractTheListOfUsers() {
        Log.info("----------------Extracting list of users-------------------");
        response = request.get("https://supervillain.herokuapp.com/v1/user");
        response.prettyPrint();
    }

    @After("@Smoke")
    public void setLogEnd()
    {
        Log.startTestCase("Execution Completed");
    }


}
